package com.example.capstone388414app

import com.google.gson.annotations.SerializedName

data class PenyakitResponse(
    @SerializedName("message")
    val message: String?
)