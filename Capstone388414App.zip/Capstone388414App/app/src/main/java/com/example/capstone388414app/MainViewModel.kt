import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.capstone388414app.PenyakitResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File

class MainViewModel : ViewModel() {
    private val apiService: ApiService

    private val _message = MutableLiveData<String>()
    val message: LiveData<String> get() = _message

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://capstone-388414.et.r.appspot.com")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(ApiService::class.java)
    }

    fun uploadImage(imageFile: File) {
        val requestFile = imageFile.asRequestBody("image/*".toMediaTypeOrNull())
        val body = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)

        viewModelScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    apiService.uploadImage(body)
                }
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    responseBody?.let {
                        processFeedback(it)
                    }
                } else {
                    _message.value = "Upload failed"
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _message.value = "Upload failed"
            }
        }
    }

        fun processFeedback(penyakitResponse: PenyakitResponse) {
        val feedback = penyakitResponse.message
        _message.value = feedback
    }
}

